package com.example.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.example.bottomnavigation.databinding.ActivityMainBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

import javax.net.ssl.TrustManager;

import okhttp3.OkHttpClient;

public class MainActivity extends AppCompatActivity {

    boolean isNightModeOn;
    Button btnLoan;
    TextView notificationBell;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
        // Initialize the binding
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        RecyclerView recyclerView = findViewById(R.id.recycler);

        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("https://i.ibb.co/f2JNznq/photo-6190430685957831105-w.jpg");
        arrayList.add("https://i.ibb.co/Y2z1kqn/photo-6190430685957831107-w.jpg");
        arrayList.add("https://i.ibb.co/XY0Nfkm/photo-6190430685957831106-w.jpg");
        arrayList.add("https://i.ibb.co/tXD8ZNV/photo-6190430685957831108-w.jpg");


        ImageAdapter adapter = new ImageAdapter(MainActivity.this, arrayList);
        adapter.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
            @Override
            public void onClick(ImageView imageView, String url) {
                ActivityOptions.makeSceneTransitionAnimation(MainActivity.this,imageView,"image").toBundle();
            }
        });
        recyclerView.setAdapter(adapter);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.home);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.home) {
                return true;
            } else if (item.getItemId() == R.id.fab) {
                startActivity(new Intent(getApplicationContext(), CustomerSupport.class));

                finish();
                return true;
            } else if (item.getItemId() == R.id.settings) {
                startActivity(new Intent(getApplicationContext(), Settings.class));

                finish();
                return true;
            } else if (item.getItemId() == R.id.faq) {
                startActivity(new Intent(getApplicationContext(), FAQ.class));

                finish();
                return true;
            } else if (item.getItemId() == R.id.account) {
                startActivity(new Intent(getApplicationContext(), Account.class));

                finish();
                return true;
            }
            return false;
        });

        btnLoan= findViewById(R.id.btnLoan);

        btnLoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), LoanCalculator.class));
                finish();
            }
        });

        notificationBell = findViewById(R.id.notificationBell);

        notificationBell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, notifications.class);
                startActivity(intent);
            }
        });

    }
}
