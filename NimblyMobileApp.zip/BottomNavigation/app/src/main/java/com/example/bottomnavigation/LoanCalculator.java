package com.example.bottomnavigation;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoanCalculator extends AppCompatActivity {

    private EditText loanAmount;
    private EditText interest;
    private EditText year;
    private EditText month;
    private TextView lEmi;
    private TextView lTenure;
    private TextView lLoanAmount;
    private TextView lInterestPayable;
    private TextView lTotalPayment;
    private TextView btnBack;
    private ALodingDialog aLodingDialog;
    private Button btnHistory;
    Connection connect;
    String ConnectionResult = "";

    FirebaseAuth auth = FirebaseAuth.getInstance();
    FirebaseUser user = auth.getCurrentUser();

    private TextView email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loan_calculator);
        System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
        btnHistory = findViewById(R.id.btnHistory);

        btnHistory.setOnClickListener(v -> {
            // Handle customize button click
            Intent intent = new Intent(LoanCalculator.this, History.class);
            startActivity(intent);
        });


        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoanCalculator.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        loanAmount = findViewById(R.id.loanAmount);
        interest = findViewById(R.id.interest);
        year = findViewById(R.id.year);
        month = findViewById(R.id.month);
        lEmi = findViewById(R.id.lEmi);
        lTenure = findViewById(R.id.lTenure);
        lLoanAmount = findViewById(R.id.lLoanAmount);
        lInterestPayable = findViewById(R.id.lInterestPayable);
        lTotalPayment = findViewById(R.id.lTotalPayment);
        aLodingDialog = new ALodingDialog(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle the Up button click
        if (item.getItemId() == android.R.id.home) {
            // Navigate back to the MainFrame activity
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Close all activities on top of MainFrame
            startActivity(intent);
            finish(); // Finish the current activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void btnsum(View view) {
        aLodingDialog.show();
        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                aLodingDialog.cancel();
            }
        };
        handler.postDelayed(runnable, 2000);

        // Get user input from EditText fields
        String loanAmountStr = loanAmount.getText().toString();
        String interestStr = interest.getText().toString();
        String yearStr = year.getText().toString();
        String monthStr = month.getText().toString();

        if (loanAmountStr.isEmpty() || interestStr.isEmpty() || yearStr.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Perform calculations
        // Convert years and months to months for easier calculation
        int yearInt = Integer.parseInt(yearStr);
        int monthInt = monthStr.isEmpty() ? 0 : Integer.parseInt(monthStr);
        int totalMonths = (yearInt * 12) + monthInt;

        double loanAmountValue = Double.parseDouble(loanAmountStr);
        double interestRate = Double.parseDouble(interestStr) / 100;

        double monthlyPayment = calculateMonthlyPayment(loanAmountValue, interestRate, totalMonths);
        double totalPayment = calculateTotalPayment(monthlyPayment, totalMonths);
        double totalInterest = calculateTotalInterest(totalPayment, loanAmountValue);

        // Update TextViews with the calculated values
        lEmi.setText(String.format("₱ %.3f", monthlyPayment));
        lTenure.setText(String.valueOf(totalMonths) + " Month/s");
        lLoanAmount.setText(String.format("₱ %.3f", loanAmountValue));
        lInterestPayable.setText(String.format("₱ %.3f", totalInterest));
        lTotalPayment.setText(String.format("₱ %.3f", totalPayment));
    }

    private double calculateMonthlyPayment(double loanAmount, double interestRate, int totalMonths) {
        double monthlyInterestRate = interestRate / 12;
        double power = Math.pow(1 + monthlyInterestRate, totalMonths);
        return loanAmount * monthlyInterestRate * power / (power - 1);
    }

    private double calculateTotalPayment(double monthlyPayment, int totalMonths) {
        return monthlyPayment * totalMonths;
    }

    private double calculateTotalInterest(double totalPayment, double loanAmount) {
        return totalPayment - loanAmount;
    }

    public void btnclear(View view) {
        loanAmount.setText("");
        interest.setText("");
        year.setText("");
        month.setText("");
        lEmi.setText("₱ 0");
        lTenure.setText("0 Month/s");
        lLoanAmount.setText("0");
        lInterestPayable.setText("₱ 0");
        lTotalPayment.setText("₱ 0");
    }
}
