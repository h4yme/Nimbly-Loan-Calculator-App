package com.example.bottomnavigation;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionHelper {
    Connection con;
    String uname, pass, ip, port, database;
    @SuppressLint("NewApi")
    public Connection connectionclass(){

        System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String ConnectionURL = null;

        try{
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            ConnectionURL = "jdbc:jtds:sqlserver://nimbly.database.windows.net:1433;DatabaseName=nimbly100;user=nimbly100;password=Nimbly_2024;sslProtocol=TLSv1.2;encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;ssl=require;";
            DriverManager.setLoginTimeout(30); // Set the login timeout to 30 seconds
            connection = DriverManager.getConnection(ConnectionURL);
        }
        catch (Exception ex){
            Log.e("Error", ex.getMessage());
        }
        return connection;
    }
}
