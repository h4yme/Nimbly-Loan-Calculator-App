package com.example.bottomnavigation;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Notification;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.bottomnavigation.RepliesAdapter;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class notifications extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NotificationAdapter adapter;
    private FirebaseAuth mAuth;

    private TextView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        mAuth = FirebaseAuth.getInstance();
        String userId = mAuth.getCurrentUser().getUid();

        recyclerView = findViewById(R.id.recyclerViewNotifications);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Use AsyncTask to fetch data from the database in the background
        new GetNotificationsTask().execute(userId);

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(notifications.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private class GetNotificationsTask extends AsyncTask<String, Void, List<Pair<String, String>>> {
        @Override
        protected List<Pair<String, String>> doInBackground(String... userIds) {
            List<Pair<String, String>> notifications = new ArrayList<>();
            try {
                ConnectionHelper connectionHelper = new ConnectionHelper();
                Connection con = connectionHelper.connectionclass();
                if (con == null) {
                    // Handle connection failure
                    return notifications;
                }

                String query = "SELECT [Notification], [Date] FROM [dbo].[Notification] WHERE [UserID] = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, userIds[0]);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    String notification = rs.getString("Notification");
                    String date = rs.getString("Date");
                    notifications.add(new Pair<>(notification, date));
                }

                rs.close();
                stmt.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return notifications;
        }

        @Override
        protected void onPostExecute(List<Pair<String, String>> notifications) {
            // Update the adapter with the fetched data
            adapter = new NotificationAdapter(notifications);
            recyclerView.setAdapter(adapter);
        }
    }

    private void insertNotification(String userId, String notificationText, String dateTime) {
        try {
            ConnectionHelper connectionHelper = new ConnectionHelper();
            Connection con = connectionHelper.connectionclass();
            if (con == null) {
                // Handle connection failure
                return;
            }

            String query = "INSERT INTO [dbo].[Notification] ([UserID], [Notification], [Date]) VALUES (?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, userId);
            stmt.setString(2, notificationText);
            stmt.setString(3, dateTime);
            stmt.executeUpdate();

            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
