package com.example.bottomnavigation;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.bottomnavigation.RepliesAdapter;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Replies extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RepliesAdapter adapter;
    private FirebaseAuth mAuth;

    private TextView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_replies);

        mAuth = FirebaseAuth.getInstance();
        String userId = mAuth.getCurrentUser().getUid();

        recyclerView = findViewById(R.id.recyclerViewReplies);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Use AsyncTask to fetch data from the database in the background
        new GetRepliesTask().execute(userId);


        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Replies.this, CustomerSupport.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private class GetRepliesTask extends AsyncTask<String, Void, List<Pair<String, String>>> {
        @Override
        protected List<Pair<String, String>> doInBackground(String... userIds) {
            List<Pair<String, String>> replies = new ArrayList<>();
            try {
                ConnectionHelper connectionHelper = new ConnectionHelper();
                Connection con = connectionHelper.connectionclass();
                if (con == null) {
                    // Handle connection failure
                    return replies;
                }

                String query = "SELECT [Reply], [Date&Time Reply] FROM [dbo].[Loan_Inquiry] WHERE [UserId] = ? AND [Status] = 'Replied'";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, userIds[0]);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    String reply = rs.getString("Reply");
                    String dateTimeReply = rs.getString("Date&Time Reply");
                    replies.add(new Pair<>(reply, dateTimeReply));

                    // Insert notification into Notification table
                    insertNotification(userIds[0], "New Reply", dateTimeReply);
                }

                rs.close();
                stmt.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return replies;
        }

        private void insertNotification(String userId, String notificationText, String dateTime) {
            try {
                ConnectionHelper connectionHelper = new ConnectionHelper();
                Connection con = connectionHelper.connectionclass();
                if (con == null) {
                    // Handle connection failure
                    return;
                }

                String query = "INSERT INTO [dbo].[Notification] ([UserID], [Notification], [Date]) VALUES (?, ?, ?)";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, userId);
                stmt.setString(2, notificationText);
                stmt.setString(3, dateTime);
                stmt.executeUpdate();

                stmt.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(List<Pair<String, String>> replies) {
            // Update the adapter with the fetched data
            adapter = new RepliesAdapter(replies);
            recyclerView.setAdapter(adapter);
        }
    }
}