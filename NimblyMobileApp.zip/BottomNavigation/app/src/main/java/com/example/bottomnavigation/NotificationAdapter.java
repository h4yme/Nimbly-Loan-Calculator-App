package com.example.bottomnavigation;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private List<Pair<String, String>> replies;

    public NotificationAdapter(List<Pair<String, String>> replies) {
        this.replies = replies;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewReply;
        TextView textViewDateReply;
        boolean isExpanded = false; // Flag to track whether the reply is expanded

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewReply = itemView.findViewById(R.id.textViewReply);
            textViewDateReply = itemView.findViewById(R.id.textViewDateReply);

            // Toggle between full and truncated reply text when clicked
            textViewReply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isExpanded) {
                        textViewReply.setMaxLines(2); // Show only 2 lines of text
                        isExpanded = false;
                    } else {
                        textViewReply.setMaxLines(Integer.MAX_VALUE); // Show all lines of text
                        isExpanded = true;
                    }
                }
            });
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.reply_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Pair<String, String> replyPair = replies.get(position);
        holder.textViewReply.setText(replyPair.first);
        holder.textViewDateReply.setText(replyPair.second);
        holder.isExpanded = false; // Reset the expansion state for each item
        holder.textViewReply.setMaxLines(2); // Show only 2 lines of text initially
    }

    @Override
    public int getItemCount() {
        return replies.size();
    }
}
