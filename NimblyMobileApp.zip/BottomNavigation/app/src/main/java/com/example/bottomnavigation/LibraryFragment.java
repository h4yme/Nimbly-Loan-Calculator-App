package com.example.bottomnavigation;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class LibraryFragment extends Fragment {

    private Button btnLogout, btnLogoutConfirm;
    private TextView email;
    FirebaseUser user;
    FirebaseAuth auth;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_library, container, false);

        // Find the button in the inflated view
        btnLogout = view.findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLogoutBottomSheet();
            }
        });

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        email = view.findViewById(R.id.email);

        if (user == null) {
            Intent intent = new Intent(getActivity(), Login.class);
            startActivity(intent);
            getActivity().finish();
        } else {
            email.setText(user.getEmail());
        }

        return view;
    }

    private void showLogoutBottomSheet() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(requireContext());
        View view1 = LayoutInflater.from(requireContext()).inflate(R.layout.bottom_sheet_layout, null);
        bottomSheetDialog.setContentView(view1);

        // Set the maximum height of the BottomSheetDialog
        CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) ((View) view1.getParent()).getLayoutParams();
        layoutParams.height = 600; // Set the maximum height in pixels
        ((View) view1.getParent()).setLayoutParams(layoutParams);

        btnLogoutConfirm = view1.findViewById(R.id.btnLogoutConfirm);
        btnLogoutConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutUser();
                bottomSheetDialog.dismiss(); // Dismiss the BottomSheetDialog after logout confirmation
            }
        });

        bottomSheetDialog.show();
    }



    private void logoutUser() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(requireContext(), Login.class);
        startActivity(intent);
        requireActivity().finish();


}
}
