package com.example.bottomnavigation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Account extends AppCompatActivity {

    private Button btnLogout, btnLogoutConfirm, btnCancel;
    private TextView email;
    FirebaseUser user;
    FirebaseAuth auth;
    Connection connection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.account);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.home) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));

                finish();
                return true;
            } else if (item.getItemId() == R.id.fab) {
                startActivity(new Intent(getApplicationContext(), CustomerSupport.class));

                finish();
                return true;
            } else if (item.getItemId() == R.id.settings) {
                startActivity(new Intent(getApplicationContext(), Settings.class));

                finish();
            } else if (item.getItemId() == R.id.faq) {
                startActivity(new Intent(getApplicationContext(), FAQ.class));

                finish();
                return true;
            } else if (item.getItemId() == R.id.account) {

                return true;
            }
            return false;
        });


        btnLogout = findViewById(R.id.btnLogout);
        email = findViewById(R.id.email);

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        if (user == null) {
            Intent intent = new Intent(Account.this, Login.class);
            startActivity(intent);
            finish();
        } else {
            email.setText(user.getEmail());
        }

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLogoutBottomSheet();
            }
        });


    }

    private void showLogoutBottomSheet() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Account.this);
        View view1 = LayoutInflater.from(Account.this).inflate(R.layout.bottom_sheet_layout, null);
        bottomSheetDialog.setContentView(view1);

        // Set the maximum height of the BottomSheetDialog
        CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) ((View) view1.getParent()).getLayoutParams();
        layoutParams.height = 600; // Set the maximum height in pixels
        ((View) view1.getParent()).setLayoutParams(layoutParams);

        btnLogoutConfirm = view1.findViewById(R.id.btnLogoutConfirm);
        btnCancel = view1.findViewById(R.id.btnCancel);
        btnLogoutConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutUser();
                bottomSheetDialog.dismiss(); // Dismiss the BottomSheetDialog after logout confirmation
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss(); // Dismiss the BottomSheetDialog on cancel
            }
        });

        bottomSheetDialog.show();
    }





    private void logoutUser() {
        FirebaseAuth.getInstance().signOut();
        // Logout from SQL database (if necessary)
        if (connection != null) {
            try {
                Statement statement = connection.createStatement();
                String updateQuery = "UPDATE LoggedInUsers SET LoggedIn = 0 WHERE UserID = " + user.getUid();
                statement.executeUpdate(updateQuery);
                statement.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        Intent intent = new Intent(Account.this, Login.class);
        startActivity(intent);
        finish();
    }

    private void setConnection(Connection connection) {
        this.connection = connection;
    }
}
