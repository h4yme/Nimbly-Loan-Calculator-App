package com.example.bottomnavigation;

public class ReplyItem {
    private String reply;
    private String dateTimeReply;

    public ReplyItem(String reply, String dateTimeReply) {
        this.reply = reply;
        this.dateTimeReply = dateTimeReply;
    }

    public String getReply() {
        return reply;
    }

    public String getDateTimeReply() {
        return dateTimeReply;
    }
}
