package com.example.bottomnavigation;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

public class SubscriptionFragment extends Fragment {

    Button btnNotif, btnCustom;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_subscription, container, false);

        btnNotif = view.findViewById(R.id.btnNotif);
        btnCustom = view.findViewById(R.id.btnCustom);

        btnNotif.setOnClickListener(v -> {
            // Handle notification button click
            Intent intent = new Intent(getActivity(), NotificationSettings.class);
            startActivity(intent);
        });

        btnCustom.setOnClickListener(v -> {
            // Handle customize button click
            Intent intent = new Intent(getActivity(), CustomizeSettings.class);
            startActivity(intent);
        });

        return view;
    }
}
