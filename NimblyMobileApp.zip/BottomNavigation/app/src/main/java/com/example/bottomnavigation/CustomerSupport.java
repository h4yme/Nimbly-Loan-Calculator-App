package com.example.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CustomerSupport extends AppCompatActivity {
    FirebaseAuth auth = FirebaseAuth.getInstance();
    FirebaseUser user = auth.getCurrentUser();
    TextView FullName, LoanAmn, YrsToPay, MessageInquiry;
    Dialog mdialog;
    Button btnInquire, btnReply;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_support);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.fab);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.home) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                finish();
                return true;
            } else if (item.getItemId() == R.id.fab) {
                return true;
            } else if (item.getItemId() == R.id.settings) {
                startActivity(new Intent(getApplicationContext(), Settings.class));
                finish();
            } else if (item.getItemId() == R.id.faq) {
                startActivity(new Intent(getApplicationContext(), FAQ.class));
                finish();
                return true;
            } else if (item.getItemId() == R.id.account) {
                startActivity(new Intent(getApplicationContext(), Account.class));
                finish();
                return true;
            }
            return false;
        });

        String EmailFinal = user.getEmail();
        String userId = user.getUid();
        FullName = findViewById(R.id.FullName);
        LoanAmn= findViewById(R.id.LoanAmn);
        YrsToPay= findViewById(R.id.YrsToPay);
        MessageInquiry= findViewById(R.id.MessageInquiry);
        btnInquire = findViewById(R.id.btnInquire);
        mdialog=new Dialog(this);
        btnReply = findViewById(R.id.btnReply);


        btnReply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CustomerSupport.this, Replies.class);
                startActivity(intent);
                finish();
            }
        });
        // Check if the user already has an existing inquiry with pending or no reply status
        boolean hasExistingInquiry = checkExistingInquiry(userId);

        // Disable all fields if there's an existing inquiry
        if (hasExistingInquiry) {
            FullName.setEnabled(false);
            LoanAmn.setEnabled(false);
            YrsToPay.setEnabled(false);
            MessageInquiry.setEnabled(false);
            btnInquire.setEnabled(false);

            // Show popup message
            mdialog.setContentView(R.layout.popupwaitinquiry);
            mdialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            mdialog.show();
        }

        btnInquire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullName = FullName.getText().toString();
                String loanAmount = LoanAmn.getText().toString();
                String yearsToPay = YrsToPay.getText().toString();
                String inquiryMsg = MessageInquiry.getText().toString();

                // Check if any of the fields are empty
                if (fullName.isEmpty() || loanAmount.isEmpty() || yearsToPay.isEmpty() || inquiryMsg.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return; // Stop further execution
                }

                // Proceed with inquiry submission
                String status = "Pending"; // Set the status to "Pending"
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                String dateTimeSend = sdf.format(new Date());

                try {
                    ConnectionHelper connectionHelper = new ConnectionHelper();
                    Connection connect = connectionHelper.connectionclass();

                    if (connect != null) {
                        Statement statement = connect.createStatement();
                        String insertQuery = "INSERT INTO Loan_Inquiry (UserId, FullName, EmailAdd, LoanAmount, YearsToPay, InquiryMsg, Reply, Status, [Date&Time Send]) " +
                                "VALUES ('" + userId + "', '" + fullName + "', '" + EmailFinal + "', '" + loanAmount + "', '" + yearsToPay + "', '" + inquiryMsg + "', '', '" + status + "', '" + dateTimeSend + "')";

                        statement.executeUpdate(insertQuery);

                        // Close the connection
                        connect.close();

                        // Show success message
                        Toast.makeText(getApplicationContext(), "Inquiry submitted successfully", Toast.LENGTH_SHORT).show();

                        // Check if status is "Replied" and show notification
                        if (status.equals("Replied")) {
                            showNotification();
                        }

                        // Clear all fields
                        FullName.setText("");
                        LoanAmn.setText("");
                        YrsToPay.setText("");
                        MessageInquiry.setText("");
                        FullName.setEnabled(false);
                        LoanAmn.setEnabled(false);
                        YrsToPay.setEnabled(false);
                        MessageInquiry.setEnabled(false);
                        btnInquire.setEnabled(false);

                        // Show popup message
                        mdialog.setContentView(R.layout.popupinquiresuccess);
                        mdialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        mdialog.show();
                    } else {
                        // Handle connection error
                        Toast.makeText(getApplicationContext(), "Failed to submit inquiry", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    // Handle SQL exception
                    Toast.makeText(getApplicationContext(), "Failed to submit inquiry", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }




    // Method to check if the user already has an existing inquiry
    private boolean checkExistingInquiry(String userId) {
        try {
            ConnectionHelper connectionHelper = new ConnectionHelper();
            Connection connect = connectionHelper.connectionclass();

            if (connect != null) {
                Statement statement = connect.createStatement();
                String query = "SELECT COUNT(*) FROM Loan_Inquiry WHERE UserId = '" + userId + "' AND Status = 'Pending' OR Reply IS NULL";
                ResultSet resultSet = statement.executeQuery(query);
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to show a notification
    private void showNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "MyChannel";
            String description = "Channel for my notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("MyChannelId", name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "MyChannelId")
                .setSmallIcon(R.drawable.baseline_notifications_24)
                .setContentTitle("New Reply")
                .setContentText("You have a new reply to your inquiry")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(1, builder.build());
    }
}
