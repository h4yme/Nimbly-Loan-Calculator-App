package com.example.bottomnavigation;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ShortsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_shorts, container, false);

        TextView text1 = view.findViewById(R.id.text1);
        TextView text2 = view.findViewById(R.id.text2);
        TextView text3 = view.findViewById(R.id.text3);
        TextView text4 = view.findViewById(R.id.text4);
        ImageView button1 = view.findViewById(R.id.button1);
        ImageView button2 = view.findViewById(R.id.button2);
        ImageView button3 = view.findViewById(R.id.button3);
        ImageView button4 = view.findViewById(R.id.button4);

        View divider1 = view.findViewById(R.id.divider1);
        View divider2 = view.findViewById(R.id.divider2);
        View divider3 = view.findViewById(R.id.divider3);
        View divider4 = view.findViewById(R.id.divider4);



        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text1.getVisibility() == View.GONE) {
                    text1.setVisibility(View.VISIBLE);
                    divider1.setVisibility(View.GONE);
                    button1.setImageResource(R.drawable.ic_arrow_up);
                } else {
                    text1.setVisibility(View.GONE);
                    divider1.setVisibility(View.VISIBLE);
                    button1.setImageResource(R.drawable.ic_arrow_down);
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text2.getVisibility() == View.GONE) {
                    text2.setVisibility(View.VISIBLE);
                    divider2.setVisibility(View.GONE);
                    button2.setImageResource(R.drawable.ic_arrow_up);
                } else {
                    text2.setVisibility(View.GONE);
                    divider2.setVisibility(View.VISIBLE);
                    button2.setImageResource(R.drawable.ic_arrow_down);
                }
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text3.getVisibility() == View.GONE) {
                    text3.setVisibility(View.VISIBLE);
                    divider3.setVisibility(View.GONE);
                    button3.setImageResource(R.drawable.ic_arrow_up);
                } else {
                    text3.setVisibility(View.GONE);
                    divider3.setVisibility(View.VISIBLE);
                    button3.setImageResource(R.drawable.ic_arrow_down);
                }
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text4.getVisibility() == View.GONE) {
                    text4.setVisibility(View.VISIBLE);
                    divider4.setVisibility(View.GONE);
                    button4.setImageResource(R.drawable.ic_arrow_up);
                } else {
                    text4.setVisibility(View.GONE);
                    divider4.setVisibility(View.VISIBLE);
                    button4.setImageResource(R.drawable.ic_arrow_down);
                }
            }
        });



        return view;
    }
}
