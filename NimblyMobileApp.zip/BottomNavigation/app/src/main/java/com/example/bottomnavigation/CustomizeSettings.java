package com.example.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;

public class CustomizeSettings extends AppCompatActivity {
Switch btnDark;
boolean isNightModeOn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customize_settings);

        TextView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the MainActivity, which hosts the SubscriptionFragment
                Intent intent = new Intent(CustomizeSettings.this, Settings.class);
                startActivity(intent);
                finish();
            }
        });




    }
}
