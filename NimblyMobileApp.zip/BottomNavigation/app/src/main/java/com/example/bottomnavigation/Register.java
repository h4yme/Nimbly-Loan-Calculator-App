package com.example.bottomnavigation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Register extends AppCompatActivity {
    EditText EmailReg, PSWReg, UsnReg, ConPSWReg; // Declare UsnReg and ConPSWReg
    Button btnRegister;
    TextView btnBack, confirmEmail, confirmUsername, confirmPasswordF, confirmRepeat;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        EmailReg = findViewById(R.id.EmailReg);
        PSWReg = findViewById(R.id.PSWReg);
        UsnReg = findViewById(R.id.UsnReg);
        ConPSWReg = findViewById(R.id.ConPSWReg);
        btnRegister = findViewById(R.id.btnRegister);
        btnBack = findViewById(R.id.btnBack);
        confirmEmail = findViewById(R.id.confirmEmail);
        confirmUsername = findViewById(R.id.confirmUsername);
        confirmPasswordF = findViewById(R.id.confirmPasswordF);
        confirmRepeat = findViewById(R.id.confirmRepeat);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // Go back to the previous activity
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email, password, username, confirmPassword;
                email = EmailReg.getText().toString();
                password = PSWReg.getText().toString();
                username = UsnReg.getText().toString();
                confirmPassword = ConPSWReg.getText().toString();


                if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    Toast.makeText(Register.this, "Enter a valid email address", Toast.LENGTH_SHORT).show();
                    confirmEmail.setTextColor(Color.RED);
                    return;
                }

                if (TextUtils.isEmpty(username) || username.length() < 4 || username.length() > 20 || !username.matches("[a-zA-Z0-9_]+")) {
                    Toast.makeText(Register.this, "Username must be between 4 and 20 characters long and can only contain letters, numbers, and underscores.", Toast.LENGTH_SHORT).show();
                    confirmUsername.setTextColor(Color.RED);
                    return;
                }

                if (TextUtils.isEmpty(password) || password.length() < 8 || !password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$")) {
                    Toast.makeText(Register.this, "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.", Toast.LENGTH_SHORT).show();
                    confirmPasswordF.setTextColor(Color.RED);
                    return;
                }

                if (!TextUtils.equals(password, confirmPassword)) {
                    Toast.makeText(Register.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    confirmRepeat.setTextColor(Color.RED);
                    return;
                }

                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {

                                    // Get the Firebase user
                                    FirebaseUser firebaseUser = mAuth.getCurrentUser();

                                    // Insert user data into SQL database
                                    if (firebaseUser != null) {
                                        ConnectionHelper connectionHelper = new ConnectionHelper();
                                        Connection connection = connectionHelper.connectionclass();

                                        if (connection != null) {
                                            try {
                                                Statement statement = connection.createStatement();
                                                String insertQuery = "INSERT INTO Users (Username, Password, EmailAddress, DateRegistered) VALUES ('" + username + "', '" + password + "', '" + email + "', GETDATE())";

                                                statement.executeUpdate(insertQuery);
                                                statement.close();
                                                connection.close();
                                            } catch (SQLException e) {
                                                e.printStackTrace();
                                                Log.e("RegisterActivity", "Failed to execute SQL query: " + e.getMessage());
                                                Toast.makeText(Register.this, "Failed to register user in SQL database", Toast.LENGTH_SHORT).show();
                                            }
                                        } else {

                                            Toast.makeText(Register.this, "Failed to connect to SQL database", Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                    // Continue with your Firebase Authentication success flow
                                    Toast.makeText(Register.this, "Account Created.", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(Register.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(Register.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed(); // Handle the Up button click
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(Register.this, Login.class);
        startActivity(intent);
        finish();
    }
}
