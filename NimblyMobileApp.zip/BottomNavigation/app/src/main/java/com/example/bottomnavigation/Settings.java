package com.example.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Switch switchLoanUpdates = findViewById(R.id.switchLoanUpdates);
        setupSwitch(switchLoanUpdates, "Loan updates");

        Switch switchAccountAlerts = findViewById(R.id.switchAccountAlerts);
        setupSwitch(switchAccountAlerts, "Account alerts");

        Switch switchPromotionOffers = findViewById(R.id.switchPromotionOffers);
        setupSwitch(switchPromotionOffers, "Promotion and offers");

        Switch switchNewsUpdates = findViewById(R.id.switchNewsUpdates);
        setupSwitch(switchNewsUpdates, "News and updates");



        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.settings);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.home) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));

                finish();
                return true;
            } else if (item.getItemId() == R.id.fab) {
                startActivity(new Intent(getApplicationContext(), CustomerSupport.class));

                finish();
                return true;
            } else if (item.getItemId() == R.id.settings) {
                return true;
            } else if (item.getItemId() == R.id.faq) {
                startActivity(new Intent(getApplicationContext(), FAQ.class));

                finish();
                return true;
            } else if (item.getItemId() == R.id.account) {
                startActivity(new Intent(getApplicationContext(), Account.class));

                finish();
                return true;
            }
            return false;
        });
    }
    private void setupSwitch(Switch switchView, final String settingName) {
        switchView.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String status = isChecked ? "enabled" : "disabled";
                String message = settingName + " " + status;
                Toast.makeText(Settings.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
