package com.example.bottomnavigation;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class History extends AppCompatActivity {

    private static final String TAG = "HistoryActivity";
    private TableLayout tableLayout;
    private ALodingDialog aLodingDialog;

    private TextView btnBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        aLodingDialog = new ALodingDialog(this);
        tableLayout = findViewById(R.id.tableLayout);
        aLodingDialog.show();
        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                aLodingDialog.cancel();
            }
        };
        handler.postDelayed(runnable,2000);
        // Establish a database connection and fetch data in a background thread
        new GetDataTask().execute();

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(History.this, LoanCalculator.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private class GetDataTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                ConnectionHelper connectionHelper = new ConnectionHelper();
                Connection connection = connectionHelper.connectionclass();

                if (connection != null) {
                    FirebaseAuth auth = FirebaseAuth.getInstance();
                    FirebaseUser user = auth.getCurrentUser();
                    if (user != null) {
                        String email = user.getEmail();

                        Statement statement = connection.createStatement();
                        String query = "SELECT LoanAmount, Interest, Date FROM TableLoanData WHERE EmailAddress = '" + email + "'";
                        ResultSet resultSet = statement.executeQuery(query);

                        // Process the ResultSet and add rows to the tableLayout
                        while (resultSet.next()) {
                            String loanAmount = resultSet.getString("LoanAmount");
                            String interest = resultSet.getString("Interest");
                            String date = resultSet.getString("Date");

                            runOnUiThread(() -> addRowToTable(loanAmount, interest, date));
                        }

                        resultSet.close();
                        statement.close();
                        connection.close();
                    } else {
                        Log.e(TAG, "User is null");
                    }
                } else {
                    Log.e(TAG, "Connection failed");
                }
            } catch (SQLException e) {
                Log.e(TAG, "SQL Exception", e);
            }
            return null;
        }

        private void addRowToTable(String loanAmount, String interest, String date) {
            TableRow row = new TableRow(History.this);
            TableRow.LayoutParams rowLayoutParams = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT);
            row.setLayoutParams(rowLayoutParams);

            // Use the same layout parameters as the TextViews in your XML layout
            TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 4);

            TextView tvLoanAmount = new TextView(History.this);
            tvLoanAmount.setLayoutParams(layoutParams);
            tvLoanAmount.setText(loanAmount);
            tvLoanAmount.setTextColor(getResources().getColor(R.color.blacklight));
            tvLoanAmount.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            tvLoanAmount.setPadding(20, 20, 20, 20);
            tvLoanAmount.setTypeface(ResourcesCompat.getFont(History.this, R.font.semi));
            tvLoanAmount.setGravity(Gravity.CENTER_HORIZONTAL);
            row.addView(tvLoanAmount);

            TextView tvInterest = new TextView(History.this);
            tvInterest.setLayoutParams(layoutParams);
            tvInterest.setText(interest);
            tvInterest.setTextColor(getResources().getColor(R.color.blacklight));
            tvInterest.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            tvInterest.setPadding(20, 20, 20, 20);
            tvInterest.setTypeface(ResourcesCompat.getFont(History.this, R.font.semi));
            tvInterest.setGravity(Gravity.CENTER_HORIZONTAL);
            row.addView(tvInterest);

            TextView tvDate = new TextView(History.this);
            tvDate.setLayoutParams(layoutParams);
            tvDate.setText(date);
            tvDate.setTextColor(getResources().getColor(R.color.blacklight));
            tvDate.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            tvDate.setPadding(20, 20, 20, 20);
            tvDate.setTypeface(ResourcesCompat.getFont(History.this, R.font.semi));
            tvDate.setGravity(Gravity.CENTER_HORIZONTAL);
            row.addView(tvDate);

            tableLayout.addView(row);

            // Add a horizontal divider

        }


    }
}
